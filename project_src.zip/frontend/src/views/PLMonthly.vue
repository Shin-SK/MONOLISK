<!-- src/views/MonthlyPL.vue -->
<script setup>
import { ref, onMounted, watch } from 'vue'
import { api } from '@/api'

const year  = ref(new Date().getFullYear())   // 2025
const store = ref('')
const stores = ref([])

const months = ref([])   // [{month:1, sales_total:..., fixed_cost:..., gross_profit:...}]

/* 店舗マスタ */
async function fetchStores() {
  stores.value = await api.get('stores/?simple=1').then(r => r.data)
}

/* 12か月まとめて取得（バックエンドで year 単位 API がある場合） */
async function fetchYearly() {
  const params = { year: year.value }
  if (store.value) params.store = store.value
  const { data } = await api.get('pl/monthly/', { params })   // ← year 引数で 12 か月返す実装に
  months.value = data.months                                  // [{month:1,...}, ... ,{month:12,...}]
}

/* --- init & reload --- */
onMounted(async () => { await fetchStores(); await fetchYearly() })
watch([year, store], fetchYearly)
</script>

<template>
<div class="container-fluid py-4">
  <h1 class="h4 mb-3">年間 P/L（{{ year }}年）</h1>

  <!-- フィルタ -->
  <div class="d-flex gap-3 mb-3 align-items-end">
    <div>
      <label class="form-label small mb-1">年度</label>
      <input type="number" v-model.number="year" class="form-control" style="max-width:120px">
    </div>
    <div>
      <label class="form-label small mb-1">店舗</label>
      <select v-model="store" class="form-select" style="max-width:200px">
        <option value="">全店舗</option>
        <option v-for="s in stores" :key="s.id" :value="s.id">{{ s.name }}</option>
      </select>
    </div>
  </div>

  <!-- 月別テーブル -->
  <div class="table-responsive">
    <table class="table table-sm align-middle">
      <thead class="table-dark">
        <tr>
          <th>月</th>
          <th class="text-end">売上</th>
          <th class="text-end">固定費</th>
          <th class="text-end">カスタム経費</th>
          <th class="text-end">粗利益</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="m in months" :key="m.month">
          <td>{{ m.month }}月</td>
          <td class="text-end">{{ $yen(m.sales_total) }}</td>
          <td class="text-end">{{ $yen(m.fixed_cost) }}</td>
          <td class="text-end">{{ $yen(m.custom_expense) }}</td>
          <td class="text-end fw-semibold" :class="m.gross_profit<0?'text-danger':''">
            {{ $yen(m.gross_profit) }}
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>
</template>
