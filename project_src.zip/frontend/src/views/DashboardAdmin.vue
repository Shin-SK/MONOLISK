<!-- views/DashboardAdmin.vue -->
<script setup>
import { ref, computed, nextTick } from 'vue'
import dayjs from 'dayjs'
import GanttChart           from '@/components/GanttChart.vue'
import ReservationFormAdmin from '@/views/ReservationFormAdmin.vue'
import { Modal }   from 'bootstrap'
import { closeSidebarThen } from '@/utils/offcanvas'

const selectedId = ref(null)
const modal      = ref(null)
const ganttRef   = ref(null)      // ⭐ 追加

/* ───────── ガント表示日 ───────── */
const selectedDate = ref(dayjs())                 // ← 任意に変わる
const selectedDateStr = computed({
  get: () => selectedDate.value.format('YYYY-MM-DD'),
  set: v  => { if (v) selectedDate.value = dayjs(v) }
})
const isSame = d => selectedDate.value.isSame(d,'day')
function go(delta){ selectedDate.value = selectedDate.value.add(delta,'day') }
function setToday(){ selectedDate.value = dayjs() }

/* ───────── ヘッダー用 “リアル今日” ───────── */
const todayLabel = dayjs().format('YYYY.MM.DD (ddd)')


/* ───────── モーダル  ───────── */
async function openModal () {
   closeSidebarThen(() => {
     modal.value = Modal.getOrCreateInstance('#reservationModal') // ★ ここで保持
     modal.value.show()
   })
}

async function openNew () {
  selectedId.value = null
  await nextTick()
  openModal()
}

async function handleBarClick ({ reservationId }) {
  selectedId.value = reservationId
  await nextTick()
  openModal()
}

function handleHide () {
  selectedId.value = null
}

/* script setup 内に追加 */
async function handleSaved () {
  modal.value?.hide()
  await ganttRef.value?.reload?.()
}
</script>

<template>
  <h1 class="h2 text-center mb-5">ダッシュボード</h1>
  <div class="dashboard-admin container-fluid">
    
    <!-- ─── 日付ヘッダー ─── -->
    <header class="gc-header d-flex align-items-center justify-content-between gap-3 mb-2">
      <!-- ← ここは常に “今日” -->
      <h5 class="mb-0">{{ todayLabel }}</h5>

      <button class="btn btn-success btn-nowrap" @click="openNew">
        ＋ 新規予約
      </button>

      <div class="wrap d-flex align-center gap-4">
      <!-- コントロール -->
        <button
          class="btn btn-outline-secondary btn-nowrap"
          :class="{ active: isSame(selectedDate.subtract(1,'day')) }"
          @click="go(-1)"
        >昨日</button>

        <button
          class="btn btn-outline-primary btn-nowrap"
          :class="{ active: isSame(dayjs()) }"
          @click="setToday"
        >今日</button>

        <button
          class="btn btn-outline-secondary btn-nowrap"
          :class="{ active: isSame(selectedDate.add(1,'day')) }"
          @click="go(1)"
        >明日</button>

        <input type="date"
              class="form-control form-control-sm ms-2 bg-white"
              v-model="selectedDateStr"/>
      </div>

    </header>
    <div class="gantchart">
      <GanttChart
        ref="ganttRef" 
        :date="selectedDateStr"
        @bar-click="handleBarClick"
        :start-hour="10"
        :hours-per-chart="24"
      />
    </div>
  </div>

  <!-- ─── Bootstrap5 モーダル ─── -->
  <div id="reservationModal"
       class="modal fade"
       tabindex="-1"
       @hidden.bs.modal="handleHide">
    <div class="modal-dialog modal-fullscreen p-4">
      <div class="modal-content">
        <div class="modal-header">
          <button class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body p-0">
          <ReservationFormAdmin
              :key="selectedId ?? 'new'"
              :reservationId="selectedId"
              :in-modal="true"
              @saved="handleSaved"/>
        </div>
      </div>
    </div>
  </div>
</template>
