<script setup>
import { ref, watch, onMounted } from 'vue'
import { api } from '@/api'             // axios インスタンス（既に使っているもの）

/* ────────── 入力（年月・店舗） ────────── */
// 「2025-07」のような文字列で保持（<input type="month"> と相性が良い）
const yearMonth = ref(new Date().toISOString().slice(0,7))
const store     = ref('')                // ''=全店舗
const stores    = ref([])                // 店舗プルダウン

/* ────────── 出力 ────────── */
const rows      = ref([])                // 日次配列
const total     = ref({                  // 合計行
  sales_total: 0,
  cast_labor: 0,
  driver_labor: 0,
  custom_expense: 0,
  gross_profit: 0,
})

/* ────────── 初期ロード ────────── */
async function fetchStores () {
  stores.value = await api.get('stores/?simple=1').then(r => r.data)
}

async function fetchData () {
  const [y,m] = yearMonth.value.split('-')
  const params = { year: y, month: m }
  if (store.value) params.store = store.value

  const { data } = await api.get('pl/monthly/', { params })
  rows.value   = data.days
  total.value  = data.monthly_total
}

onMounted(async () => {
  await fetchStores()
  await fetchData()
})

// 入力が変わったら自動再読込
watch([yearMonth, store], fetchData)
</script>

<template>
<div class="container-fluid py-4">
  <h1 class="h4 mb-3">月次 P/L</h1>

  <!-- フィルタ UI -->
  <div class="d-flex gap-3 mb-3 align-items-end">
    <div>
      <label class="form-label small mb-1">対象月</label>
      <input type="month" v-model="yearMonth" class="form-control" style="max-width:180px">
    </div>
    <div>
      <label class="form-label small mb-1">店舗</label>
      <select v-model="store" class="form-select" style="max-width:200px">
        <option value="">全店舗</option>
        <option v-for="s in stores" :key="s.id" :value="s.id">{{ s.name }}</option>
      </select>
    </div>
  </div>

  <!-- 明細テーブル -->
  <div class="table-responsive">
    <table class="table table-sm align-middle">
      <thead class="table-dark">
        <tr>
          <th class="text-nowrap">日付</th>
          <th class="text-end">売上</th>
          <th class="text-end">キャスト人件費</th>
          <th class="text-end">ドライバー人件費</th>
          <th class="text-end">カスタム経費</th>
          <th class="text-end">粗利益</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="d in rows" :key="d.date">
          <td class="text-nowrap">{{ d.date }}</td>
          <td class="text-end">{{ $yen(d.sales_total) }}</td>
          <td class="text-end">{{ $yen(d.cast_labor) }}</td>
          <td class="text-end">{{ $yen(d.driver_labor) }}</td>
          <td class="text-end">{{ $yen(d.custom_expense) }}</td>
          <td class="text-end fw-semibold" :class="d.gross_profit < 0 ? 'text-danger' : ''">
            {{ $yen(d.gross_profit) }}
          </td>
        </tr>
      </tbody>
      <!-- 合計行 -->
      <tfoot>
        <tr class="table-secondary fw-bold">
          <td class="text-end">合計</td>
          <td class="text-end">{{ $yen(total.sales_total) }}</td>
          <td class="text-end">{{ $yen(total.cast_labor) }}</td>
          <td class="text-end">{{ $yen(total.driver_labor) }}</td>
          <td class="text-end">{{ $yen(total.custom_expense) }}</td>
          <td class="text-end">{{ $yen(total.gross_profit) }}</td>
        </tr>
      </tfoot>
    </table>
  </div>
</div>
</template>

<!-- 最低限のスタイルだけ付与（後で好きにカスタム OK） -->
<style scoped>
.table-responsive { max-height: 70vh; }
</style>
