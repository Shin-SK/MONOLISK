<template>
  <SidebarOffcanvas />
  <router-view />
  <div class="cr">MONOLISK</div>
</template>


<script setup>
import SidebarOffcanvas from '@/components/SidebarOffcanvas.vue'
</script>