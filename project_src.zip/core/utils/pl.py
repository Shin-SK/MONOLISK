# core/utils/pl.py
from datetime import date, timedelta
from django.db.models import Sum, Q
from core.models import (
	Reservation, ReservationCast, ReservationCharge,
	CastRate, DriverRate, ShiftAttendance, DriverShift,
	RankCourse, CastCoursePrice,
	ExpenseEntry
)
from decimal import Decimal
import logging
logger = logging.getLogger(__name__)



# ───────── 素コース価格を返す ─────────
def _base_course_price(rc: ReservationCast) -> int:
	"""
	rc: ReservationCast インスタンス
	優先順:
	  1) CastCoursePrice (キャスト個別価格)
	  2) RankCourse	 (店舗ランク標準価格)
	"""
	# ① キャスト個別
	ccp = (
		CastCoursePrice.objects
		.filter(cast_profile=rc.cast_profile, course=rc.course)
		.first()
	)
	if ccp and ccp.custom_price:
		return ccp.custom_price

	# ② 店舗ランク標準
	rank_course = (
		RankCourse.objects
		.filter(store=rc.reservation.store,
				rank=rc.cast_profile.rank,
				course=rc.course)
		.first()
	)
	return rank_course.base_price if rank_course else 0



def _latest_cast_rate_map(target: date) -> dict[int, tuple[int|None, Decimal]]:
	"""
	cast_profile_id ➜ (hourly_rate, commission_pct)
	RDB に依存しない方法で「最新レートだけ」を抜き出す
	"""
	rate_map: dict[int, tuple[int|None, Decimal]] = {}
	qs = (
		CastRate.objects
		.filter(effective_from__lte=target)
		.order_by('cast_profile', '-effective_from')   # 新しい順に並ぶ
	)
	for r in qs:
		# 1回目に出てきたレコード = cast_profile ごとの最新
		rate_map.setdefault(
			r.cast_profile_id,
			(r.hourly_rate, r.commission_pct or Decimal('0'))
		)
	return rate_map

# --- 追加: driver 用ヘルパ --------------------------
def _latest_driver_rate_map(target: date) -> dict[int, int]:
	"""
	driver_id ➜ hourly_rate
	DISTINCT ON を使わずに Python 側で「最新レコードだけ」を抽出
	"""
	drv_map: Dict[int, int] = {}
	qs = (
		DriverRate.objects
		.filter(effective_from__lte=target)
		.order_by('driver', '-effective_from')   # 新しい順
	)
	for r in qs:
		drv_map.setdefault(r.driver_id, r.hourly_rate or 0)
	return drv_map

def _calc_cast_labor(target: date, store=None) -> int:
	"""
	時給制キャスト → (勤務時間 × 時給)
	歩合キャスト   → (コース素価格 × commission_pct) + (オプション合計 × 50%)
	"""

	# ── 最新レート辞書（cast_id ➜ (hourly, pct)）──
	latest_rates = (
		CastRate.objects
		.filter(effective_from__lte=target)
		.order_by('cast_profile', '-effective_from')
		.distinct('cast_profile')
	)
	rate_map = _latest_cast_rate_map(target)
	total = 0

	# ───────────────────────────────────
	# ① 時給キャスト（打刻から算出）
	# ───────────────────────────────────
	sa_qs = ShiftAttendance.objects.filter(
		checked_in_at__date=target,
		checked_out_at__isnull=False,
	)
	if store:
		sa_qs = sa_qs.filter(cast_profile__store_id=store)

	for sa in sa_qs.select_related('cast_profile'):
		hr, pct = rate_map.get(sa.cast_profile_id, (None, None))
		if hr:   # 時給があればそれを採用
			hours = (sa.checked_out_at - sa.checked_in_at).total_seconds() / 3600
			total += hr * hours

	# ───────────────────────────────────
	# ② 歩合キャスト（予約から算出）
	# ───────────────────────────────────
	res_qs = Reservation.objects.filter(start_at__date=target)
	if store:
		res_qs = res_qs.filter(store_id=store)

	logger.debug("  rate_map keys=%s", list(rate_map.keys()))
	logger.debug("  ShiftAttendance qs=%s", sa_qs.count())

	# 予約→オプション売上合計（OPTION のみ）
	opt_sum = (
		ReservationCharge.objects
		.filter(reservation__in=res_qs, kind='OPTION')
		.values('reservation')
		.annotate(s=Sum('amount'))   # ← ここを 'amount' に
	)
	opt_map = {row['reservation']: row['s'] or 0 for row in opt_sum}

	# 歩合キャストごとに人件費を積算
	rc_qs = (
		ReservationCast.objects
		.filter(reservation__in=res_qs)
		.select_related('reservation', 'cast_profile', 'course')
	)
	for rc in rc_qs:
		hr, pct = rate_map.get(rc.cast_profile_id, (None, None))
		if hr:		# 時給設定がある人は①ですでに計上済み
			continue
		if not pct:   # どちらも入っていなければ 0
			continue

		base_price  = _base_course_price(rc)
		option_part = Decimal(opt_map.get(rc.reservation_id, 0)) * Decimal('0.5')
		total += (Decimal(base_price) * (pct / Decimal('100'))) + option_part

	return int(total)



def get_daily_pl(target: date, store: int | None = None) -> dict:
	# ========= 売上 =========
	res_qs = Reservation.objects.filter(start_at__date=target)
	if store:
		res_qs = res_qs.filter(store_id=store)
	sales_total = res_qs.aggregate(s=Sum("received_amount"))["s"] or 0

	# ========= キャスト人件費 =========
	cast_labor = _calc_cast_labor(target, store)

	# ========= ドライバー人件費 =========
	drv_qs = DriverShift.objects.filter(date=target)
	if store:
		drv_qs = drv_qs.filter(driver__store_id=store)

	drv_rate_map = _latest_driver_rate_map(target)   # ← ここだけ置換

	driver_labor = sum(
		((ds.clock_out_at - ds.clock_in_at).total_seconds() / 3600)
		* drv_rate_map.get(ds.driver_id, 0)
		for ds in drv_qs
		if ds.clock_in_at and ds.clock_out_at
	)

	# ========= カスタム経費 =========
	exp_qs = ExpenseEntry.objects.filter(date=target, category__is_fixed=False)
	if store:
		exp_qs = exp_qs.filter(Q(store_id=store) | Q(store__isnull=True))
	custom_expense = exp_qs.aggregate(s=Sum("amount"))["s"] or 0

	# ========= 粗利 =========
	gross = sales_total - cast_labor - driver_labor - custom_expense

	return {
		"date":		   target.isoformat(),
		"sales_total":	int(sales_total),
		"cast_labor":	 int(cast_labor),
		"driver_labor":   int(driver_labor),
		"custom_expense": int(custom_expense),
		"gross_profit":   int(gross),
	}

