#veiws.py
from rest_framework import viewsets, permissions ,filters, status, mixins
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from .filters import CustomerFilter
from rest_framework.decorators import action
from rest_framework.filters import OrderingFilter
from django.shortcuts import get_object_or_404
from django.db.models import Exists, OuterRef, Q, Sum, Subquery, IntegerField, Value, Case, When, F, DateField
from django.db.models.functions import Coalesce
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.utils import timezone
from datetime import date, timedelta
from calendar import monthrange
from django.db.models.functions import TruncDate, TruncMonth
from core.utils.pl import get_daily_pl


from .models import (
    Store, Rank, Course, RankCourse, Option, GroupOptionPrice,
    CastProfile, CastCoursePrice, CastOption, Driver, Customer,
    Reservation, ReservationCast, CustomerAddress, ShiftPlan, ShiftAttendance, ReservationDriver, DriverShift, ExpenseCategory, ExpenseEntry, CastRate, DriverRate
)
from .serializers import (
    StoreSerializer, RankSerializer, CourseSerializer, RankCourseSerializer,
    OptionSerializer, GroupOptionPriceSerializer,
    CastSerializer, CastCoursePriceSerializer, CastOptionSerializer,
    DriverSerializer, CustomerSerializer, ReservationSerializer, DriverListSerializer,
    CustomerReservationSerializer,CustomerAddressSerializer, ShiftPlanSerializer, ShiftAttendanceSerializer, ReservationDriverSerializer ,DriverShiftSerializer,
    ExpenseEntrySerializer, ExpenseCategorySerializer, DailyPLSerializer,
    DriverRateSerializer, CastRateSerializer
)
from.filters import (
    ReservationFilter,CastProfileFilter, CustomerFilter, ShiftPlanFilter, ReservationDriverFilter
)



# ---- 基本 read/write 権限は STAFF。調整は後で ----
class IsStaff(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_superuser or request.user.groups.filter(name='STAFF').exists()

# ---------- マスタ ----------
class StoreViewSet(viewsets.ModelViewSet):
    queryset = Store.objects.all()
    serializer_class = StoreSerializer
    permission_classes = [AllowAny]

class RankViewSet(viewsets.ModelViewSet):
    queryset = Rank.objects.all()
    serializer_class = RankSerializer
    permission_classes = [AllowAny]

class CourseViewSet(viewsets.ModelViewSet):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    permission_classes = [AllowAny]

class RankCourseViewSet(viewsets.ModelViewSet):
    queryset = RankCourse.objects.select_related('store','rank','course')
    serializer_class = RankCourseSerializer
    permission_classes = [AllowAny]

class OptionViewSet(viewsets.ModelViewSet):
    queryset = Option.objects.all()
    serializer_class = OptionSerializer
    permission_classes = [AllowAny]

class GroupOptionPriceViewSet(viewsets.ModelViewSet):
    queryset = GroupOptionPrice.objects.select_related('store','course')
    serializer_class = GroupOptionPriceSerializer
    permission_classes = [AllowAny]

# ---------- キャスト ----------
class CastViewSet(viewsets.ModelViewSet):
    queryset = CastProfile.objects.select_related('store','rank')
    serializer_class = CastSerializer
    permission_classes = [AllowAny]

class CastCoursePriceViewSet(viewsets.ModelViewSet):
    queryset = CastCoursePrice.objects.select_related('cast','course')
    serializer_class = CastCoursePriceSerializer
    permission_classes = [AllowAny]

class CastOptionViewSet(viewsets.ModelViewSet):
    queryset = CastOption.objects.select_related('option')
    serializer_class = CastOptionSerializer
    permission_classes = [permissions.IsAdminUser]   # STAFF のみに変更したければ
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['cast_profile']


# ---------- 顧客・ドライバー ----------

# ---------- ドライバー ----------
class DriverViewSet(viewsets.ReadOnlyModelViewSet):
    """
    /api/drivers/<id>/
        ├─ POST  clock_in/             … 出勤＆レコード新規作成
        └─ GET   shifts/?date=2025-07-02 … その日の勤怠一覧（1件だけ想定）
    """
    queryset = Driver.objects.select_related('user', 'store')
    serializer_class = DriverSerializer
    permission_classes = [permissions.IsAuthenticated]

    # -- 出勤 -------------------------------------------------
    @action(detail=True, methods=['post'])
    def clock_in(self, request, pk=None):
        driver = self.get_object()
        today  = timezone.localdate()

        shift, created = DriverShift.objects.get_or_create(
            driver=driver, date=today,
            defaults={
                'float_start': request.data.get('float_start', 0),
                'clock_in_at': timezone.now(),
            }
        )
        ser = DriverShiftSerializer(shift)
        return Response(ser.data, status=status.HTTP_201_CREATED)

    # -- 勤怠一覧（1ドライバー分） ----------------------------
    @action(detail=True, methods=['get'])
    def shifts(self, request, pk=None):
        driver = self.get_object()
        qs = driver.shifts.all()
        if date := request.query_params.get('date'):
            qs = qs.filter(date=date)
        return Response(DriverShiftSerializer(qs, many=True).data)



class DriverShiftViewSet(
        mixins.ListModelMixin,          # ★ 追加
        mixins.RetrieveModelMixin,
        viewsets.GenericViewSet):

    """
    /api/driver-shifts/<shift_id>/
        └─ PATCH clock_out/ … 退勤
    """
    queryset = DriverShift.objects.select_related('driver__user')
    serializer_class = DriverShiftSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends   = [DjangoFilterBackend]
    filterset_fields  = ['date', 'driver__store', 'driver']

    def get_queryset(self):
        qs = super().get_queryset()

        # STAFF 絞り込みはそのまま
        if not (self.request.user.is_superuser or
                self.request.user.groups.filter(name='STAFF').exists()):
            qs = qs.filter(driver__user=self.request.user)

        # --- 集金額サブクエリ ---

        rd_sub = (
            ReservationDriver.objects
            .filter(
                driver_id=OuterRef("driver_id"),
                reservation__start_at__date=OuterRef("date"),
                role=ReservationDriver.Role.DROP_OFF,
            )
            .annotate(          # ★ collected_amount 優先／無ければ received_amount
                effective_amount=Case(
                    When(collected_amount__isnull=True,
                        then=F("reservation__received_amount")),
                    default=F("collected_amount"),
                    output_field=IntegerField(),
                )
            )
            .values("driver_id")
            .annotate(s=Sum("effective_amount"))
            .values("s")[:1]
        )

        # ★ 別名で注入
        qs = qs.annotate(
            total_received_calc=Coalesce(Subquery(rd_sub, output_field=IntegerField()), Value(0))
        )

        return qs.order_by('driver_id')

    @action(detail=True, methods=['post'])
    def clock_in(self, request, pk=None):
        """
        STAFF なら pk(=URL上の driver_id) で誰でも出勤させられる。
        ドライバー本人は自分の pk でしか叩けない。
        """
        driver = self.get_object()

        # 本人以外 & STAFF でない → 拒否
        if driver.user != request.user \
        and not (request.user.is_superuser or request.user.groups.filter(name='STAFF').exists()):
            return Response({"detail": "権限がありません"}, status=403)

        today = timezone.localdate()
        shift, _ = DriverShift.objects.get_or_create(
            driver=driver, date=today,
            defaults={
                "float_start": request.data.get("float_start", 0),
                "clock_in_at": timezone.now(),
            }
        )
        return Response(DriverShiftSerializer(shift).data, status=201)


    @action(detail=True, methods=['patch'])
    def clock_out(self, request, pk=None):
        shift = self.get_object()
        serializer = self.get_serializer(
            shift, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save(clock_out_at=timezone.now())

        return Response(self.get_serializer(shift).data)



class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer
    permission_classes = [AllowAny]
    filter_backends = [
        DjangoFilterBackend,
    ]
    search_fields   = ['phone', 'name']   # ← ② 追加
    filterset_class    = CustomerFilter

    @action(detail=True, methods=["get"])
    def latest_reservation(self, request, pk=None):
        """顧客の直近 1 件"""
        r = (
            Reservation.objects
            .filter(customer_id=pk)
            .order_by("-start_at")
            .select_related("store")
            .prefetch_related("casts__cast_profile")
            .first()
        )
        if not r:
            return Response(None)
        ser = CustomerReservationSerializer(r)
        return Response(ser.data)

    @action(detail=True, methods=["get"])
    def reservations(self, request, pk=None):
        """
        顧客の予約一覧（?limit=20 & ?offset=40 も使える）
        """
        qs = (
            Reservation.objects
            .filter(customer_id=pk)
            .order_by("-start_at")
            .select_related("store")
            .prefetch_related("casts__cast_profile")
        )
        # pagination は DRF のデフォルトをそのまま
        page = self.paginate_queryset(qs)
        ser  = CustomerReservationSerializer(page, many=True)
        return self.get_paginated_response(ser.data)


# ---------- 予約 ----------


class ReservationViewSet(viewsets.ModelViewSet):
    queryset = (
        Reservation.objects
        .select_related("store", "driver", "customer")
        .prefetch_related(
            "casts__cast_profile",
            "charges",
            "drivers__driver__user",  # ★ 追加
        )
    )
    serializer_class    = ReservationSerializer
    permission_classes  = [AllowAny]
    pagination_class    = None      # ← 必要なら外して OK

    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_class   = ReservationFilter 
    # filterset_fields = ['customer']	
    ordering_fields = ["start_at", "id"]      # 並び替え許可フィールド
    ordering = ["-start_at"]                  # ← デフォルトを新しい順に

    # ------- 共通ヘルパ -------
    def _sync_casts(self, reservation, casts_data):
        """
        受け取った casts 配列で ReservationCast 行を置き換える
        """
        ReservationCast.objects.filter(reservation=reservation).delete()
        objs = [
            ReservationCast(
                reservation    = reservation,
                cast_profile_id= c["cast_profile"],
                rank_course_id = c["rank_course"],
            )
            for c in casts_data
        ]
        ReservationCast.objects.bulk_create(objs)


    @action(detail=False, methods=['get'], url_path='mine')
    def mine(self, request):
        if not request.user.groups.filter(name='CAST').exists():
            return Response(status=403)
        qs = self.filter_queryset(self.get_queryset())
        qs = qs.filter(casts__cast_profile__user=request.user)
        date = request.query_params.get('date')
        if date:
            qs = qs.filter(start_at__date=date)
        serializer = self.get_serializer(qs, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'], url_path='mine-driver')
    def mine_driver(self, request):
        """ログイン中ドライバー本人だけの予約"""
        if not request.user.groups.filter(name='DRIVER').exists():
            return Response(status=403)

        qs = self.filter_queryset(self.get_queryset())
        qs = qs.filter(
            Q(drivers__driver__user=request.user) |   # ← PU / DO 中間テーブル
            Q(driver__user=request.user)              # ← 旧 single FK (残していても OK)
        ).distinct()

        # ① 期間フィルタを追加
        date_from = request.query_params.get('from')
        date_to   = request.query_params.get('to')
        single    = request.query_params.get('date')

        if single:
            qs = qs.filter(start_at__date=single)
        else:
            if date_from:
                qs = qs.filter(start_at__date__gte=date_from)
            if date_to:
                qs = qs.filter(start_at__date__lte=date_to)

        return Response(self.get_serializer(qs, many=True).data)


    @action(detail=False, methods=['get'], url_path='mine-cast')
    def mine_cast(self, request):
        if not request.user.groups.filter(name='CAST').exists():
            return Response(status=403)

        qs = self.filter_queryset(self.get_queryset())
        qs = qs.filter(casts__cast_profile__user=request.user)

        # ↓★ 期間フィルタを driver と同じ形で追加
        date_from = request.query_params.get('from')
        date_to   = request.query_params.get('to')
        single    = request.query_params.get('date')

        if single:
            qs = qs.filter(start_at__date=single)
        else:
            if date_from:
                qs = qs.filter(start_at__date__gte=date_from)
            if date_to:
                qs = qs.filter(start_at__date__lte=date_to)

        return Response(self.get_serializer(qs, many=True).data)


    @action(detail=False, methods=['delete'], url_path='bulk-delete')
    def bulk_delete(self, request):
        """
        payload: { "ids": [1, 2, 3] }
        """
        ids = request.data.get('ids', [])
        if not ids:
            return Response(
                {"detail": "ids を配列で送ってください"},
                status=status.HTTP_400_BAD_REQUEST
            )
        deleted, _ = Reservation.objects.filter(id__in=ids).delete()
        return Response({"deleted": deleted}, status=status.HTTP_204_NO_CONTENT)


class CastProfileViewSet(viewsets.ModelViewSet):
    queryset = CastProfile.objects.select_related("store", "rank", "performer")
    serializer_class = CastSerializer
    permission_classes = [IsStaff]
    filter_backends   = [DjangoFilterBackend]
    filterset_class   = CastProfileFilter
    
    # --- これだけ ---
    def get_queryset(self):
        qs = super().get_queryset()
        store_id = self.request.query_params.get("store")
        if store_id:
            qs = qs.filter(store_id=store_id)
        return qs



class CustomerAddressViewSet(viewsets.ModelViewSet):
	serializer_class = CustomerAddressSerializer
	permission_classes = [AllowAny]

	def get_queryset(self):
		return CustomerAddress.objects.filter(customer_id=self.kwargs['customer_pk'])

	def perform_create(self, serializer):			# ★ 追加
		customer = get_object_or_404(Customer, pk=self.kwargs['customer_pk'])
		serializer.save(customer=customer)




class ShiftPlanViewSet(viewsets.ModelViewSet):
    queryset = ShiftPlan.objects.all()          # ★ 追加
    serializer_class = ShiftPlanSerializer
    permission_classes = [IsStaff]
    filter_backends   = [DjangoFilterBackend]
    filterset_class   = ShiftPlanFilter

    def get_queryset(self):
        qs = (
            super()
            .get_queryset()
            .select_related("cast_profile__store")
            .annotate(
                is_checked_in = Exists(
                    ShiftAttendance.objects.filter(
                        shift_plan=OuterRef("pk"),
                        checked_out_at__isnull=True
                    )
                )
            )
        )
        # date 未指定なら今日
        if "date" not in self.request.query_params:
            qs = qs.filter(date=timezone.localdate())
        return qs

# core/views.py  ── 末尾あたりに追記
class ShiftAttendanceViewSet(viewsets.ModelViewSet):
    """打刻専用 ViewSet: /shift-attendances/<pk>/checkin|checkout/"""
    queryset           = ShiftAttendance.objects.all()
    serializer_class   = ShiftAttendanceSerializer
    http_method_names  = ["get", "post", "head", "options"]

    @action(detail=True, methods=["post"])
    def checkin(self, request, pk=None):
        sa = self.get_object()
        at = request.data.get("at") or timezone.now()
        sa.checked_in_at = at
        sa.save(update_fields=["checked_in_at"])
        return Response(self.get_serializer(sa).data)

    @action(detail=True, methods=["post"])
    def checkout(self, request, pk=None):
        sa = self.get_object()
        at = request.data.get("at") or timezone.now()
        sa.checked_out_at = at
        sa.save(update_fields=["checked_out_at"])
        return Response(self.get_serializer(sa).data)




class ReservationDriverViewSet(viewsets.ModelViewSet):
    """
    /api/reservation-drivers/
    - list: ?reservation=123 で予約ごとの PU/DO 一覧
    - create: ドライバーアサイン or 集金登録
    - partial_update (PATCH): 時刻や金額の確定
    """
    queryset         = ReservationDriver.objects.select_related(
        "driver__user", "reservation"
    )
    serializer_class = ReservationDriverSerializer
    filterset_class  = ReservationDriverFilter
    permission_classes = [permissions.IsAuthenticated]


class SalesSummary(APIView):
    permission_classes = [IsStaff]          # 適宜

    def get(self, request):
        # qs = Reservation.objects.filter(status=Reservation.Status.CLOSED) もし締めボタン的なの作るなら使う
        qs = Reservation.objects.all()

        store = request.GET.get('store')
        if store:
            qs = qs.filter(store_id=store)

        date_from = request.GET.get('from')
        date_to   = request.GET.get('to')

        if date_from:
            qs = qs.filter(start_at__date__gte=date_from)
        if date_to:
            qs = qs.filter(start_at__date__lte=date_to)

        total = qs.aggregate(total=Sum('received_amount'))['total'] or 0

        # 今日 & 今月
        today = timezone.localdate()
        today_total = qs.filter(start_at__date=today)       \
                        .aggregate(t=Sum('received_amount'))['t'] or 0
        month_total = qs.filter(start_at__month=today.month,
                                start_at__year=today.year)  \
                        .aggregate(t=Sum('received_amount'))['t'] or 0

        return Response({
            'total': total,
            'today_total': today_total,
            'month_total': month_total
        })




class ExpenseCategoryViewSet(viewsets.ModelViewSet):
    queryset = ExpenseCategory.objects.filter(is_active=True)
    serializer_class = ExpenseCategorySerializer
    permission_classes = [permissions.IsAuthenticated]  # 適宜

class ExpenseEntryViewSet(viewsets.ModelViewSet):
    """
    /api/expenses/?date=2025-07-03&store=<id>
    """
    queryset = ExpenseEntry.objects.select_related('category', 'store')
    serializer_class = ExpenseEntrySerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends   = [DjangoFilterBackend]
    filterset_fields  = ['date', 'store', 'category']





class DailyPLView(APIView):
    """
    /api/pl/daily/?date=2025-07-03&store=<id|null>
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
         target = request.GET.get("date") or date.today().isoformat()
         store  = request.GET.get("store")
         data   = get_daily_pl(date.fromisoformat(target),
                               int(store) if store else None)
         return Response(data)


class MonthlyPLView(APIView):
    """
    /api/pl/monthly/?month=2025-07&store=<id|null>
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        month_str = request.GET.get("month") or date.today().strftime("%Y-%m")
        yyyy, mm  = map(int, month_str.split("-"))
        first_day = date(yyyy, mm, 1)
        last_day  = date(yyyy, mm, monthrange(yyyy, mm)[1])
        store     = request.GET.get("store")

        # 売上 -----------------------------------------------------------
        res_qs = Reservation.objects.filter(start_at__date__range=(first_day, last_day))
        if store: res_qs = res_qs.filter(store_id=store)
        sales = res_qs.aggregate(t=Sum("received_amount"))["t"] or 0

        # キャスト人件費 -------------------------------------------------
        sa_qs = ShiftAttendance.objects.filter(
            checked_in_at__date__range=(first_day, last_day)
        )
        if store: sa_qs = sa_qs.filter(cast_profile__store_id=store)
        cast_rate = (
            CastRate.objects
            .filter(effective_from__lte=last_day)
            .order_by("cast_profile", "-effective_from")
            .distinct("cast_profile")
        )
        rate_map = {r.cast_profile_id: r.hourly_rate or 0 for r in cast_rate}
        cast_cost = 0
        for sa in sa_qs:
            hr = rate_map.get(sa.cast_profile_id, 0)
            if sa.checked_out_at and sa.checked_in_at:
                cast_cost  = hr * ((sa.checked_out_at -
                                    sa.checked_in_at).total_seconds() / 3600)

        # ドライバー人件費 ---------------------------------------------
        ds_qs = DriverShift.objects.filter(date__range=(first_day, last_day))
        if store: ds_qs = ds_qs.filter(driver__store_id=store)
        driver_rate = (
            DriverRate.objects
            .filter(effective_from__lte=last_day)
            .order_by("driver", "-effective_from")
            .distinct("driver")
        )
        dr_map = {r.driver_id: r.hourly_rate or 0 for r in driver_rate}
        driver_cost = 0
        for ds in ds_qs:
            if ds.clock_out_at and ds.clock_in_at:
                driver_cost  = dr_map.get(ds.driver_id, 0) * (
                    (ds.clock_out_at - ds.clock_in_at).total_seconds() / 3600
                )

        # 固定費／カスタム経費 -----------------------------------------
        fx_exp  = ExpenseEntry.objects.filter(
            date__range=(first_day, last_day),
            category__is_fixed=True,
        )
        ct_exp  = ExpenseEntry.objects.filter(
            date__range=(first_day, last_day),
            category__is_fixed=False,
        )
        if store:
            fx_exp = fx_exp.filter(store_id__in=[store, None])
            ct_exp = ct_exp.filter(store_id=store)

        fixed_exp   = fx_exp.aggregate(t=Sum("amount"))["t"] or 0
        custom_exp  = ct_exp.aggregate(t=Sum("amount"))["t"] or 0

        operating = sales - cast_cost - driver_cost - fixed_exp - custom_exp

        data = {
            "month": month_str,
            "sales_total": sales,
            "cast_labor": int(cast_cost),
            "driver_labor": int(driver_cost),
            "fixed_expense": fixed_exp,
            "custom_expense": custom_exp,
            "operating_profit": int(operating),
        }
        return Response(MonthlyPLSerializer(data).data)



class MonthlyPLView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        year  = int(request.GET.get("year", timezone.localdate().year))
        month = int(request.GET.get("month", timezone.localdate().month))
        store = request.GET.get("store")   # None=全店舗

        # その月の日付リストを作成
        first_day = date(year, month, 1)
        next_month = (first_day.replace(day=28) + timedelta(days=4)).replace(day=1)
        days = (next_month - first_day).days

        daily_rows = []
        month_totals = {
            "sales_total": 0,
            "cast_labor": 0,
            "driver_labor": 0,
            "custom_expense": 0,
            "gross_profit": 0,
        }

        for d in range(days):
            curr = first_day + timedelta(days=d)
            row  = get_daily_pl(curr, store)
            daily_rows.append(row)
            for k in month_totals:
                month_totals[k]  = row[k]

        return Response({
            "year": year,
            "month": month,
            "store": store,
            "days":  daily_rows,
            "monthly_total": month_totals
        })


class CastRateViewSet(viewsets.ReadOnlyModelViewSet):
    """
    /api/cast-rates/?cast_profile=<id>
    """
    queryset = CastRate.objects.all()
    serializer_class = CastRateSerializer
    permission_classes = [IsAuthenticated]
    filter_backends   = [DjangoFilterBackend]
    filterset_fields  = ['cast_profile']

class DriverRateViewSet(viewsets.ReadOnlyModelViewSet):
    """
    /api/driver-rates/?driver=<id>
    """
    queryset = DriverRate.objects.all()
    serializer_class = DriverRateSerializer
    permission_classes = [IsAuthenticated]
    filter_backends   = [DjangoFilterBackend]
    filterset_fields  = ['driver']