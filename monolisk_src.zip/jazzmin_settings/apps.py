from django.apps import AppConfig


class JazzminSettingsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jazzmin_settings'
    verbose_name = "設定"
