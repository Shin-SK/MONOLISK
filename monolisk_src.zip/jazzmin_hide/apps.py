from django.apps import AppConfig


class JazzminHideConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "jazzmin_hide"
    verbose_name = "その他"          # サイドバー見出し名
