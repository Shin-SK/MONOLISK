<template>
  <router-view />
  <div class="cr">MONOLISK</div>
</template>
